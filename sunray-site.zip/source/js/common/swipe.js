// функция для swipe на главной

(function(){
	// $(".main-slider__list").swipe( {
	// 	swipeLeft:leftSwipe,
	// 	swipeRight:rightSwipe,
	// });
	// function leftSwipe(event){
	// 	alert('swipe left');
	// }
	// function rightSwipe(event){
	// 	alert('swipe right');
	// }
})();